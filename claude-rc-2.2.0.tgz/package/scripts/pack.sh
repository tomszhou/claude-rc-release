#!/bin/bash
set -e

echo "=== 1. Inject build info ==="
VERSION=$(node -p "require('./package.json').version")
BUILD_TIME=$(date '+%Y-%m-%d %H:%M:%S')
cat > src/build-info.ts << EOF
// Auto-generated at build time by scripts/pack.sh
export const VERSION = "${VERSION}";
export const BUILD_TIME = "${BUILD_TIME}";
EOF
echo "  Version: ${VERSION}, Build: ${BUILD_TIME}"

echo "=== 2. Compile TypeScript ==="
npx tsc

echo "=== 3. Obfuscate JS files ==="
for f in dist/index.js dist/src/*.js; do
  echo "  Obfuscating $f ..."
  npx javascript-obfuscator "$f" \
    --output "$f" \
    --target node \
    --ignore-imports true \
    --string-array true \
    --string-array-encoding base64 \
    --string-array-threshold 0.75 \
    --rename-globals false \
    --self-defending false \
    --control-flow-flattening false \
    --dead-code-injection false \
    --numbers-to-expressions true \
    --simplify true
done

echo "=== 4. Ensure shebang ==="
for f in dist/index.js dist/src/cli.js; do
  if ! head -1 "$f" | grep -q '^#!/usr/bin/env node'; then
    sed -i '' '1i\
#!/usr/bin/env node
' "$f"
    echo "  Added shebang to $f"
  else
    echo "  Shebang OK: $f"
  fi
done

echo "=== 5. Pack ==="
rm -f claude-rc-*.tgz
npm pack --ignore-scripts

echo "=== Done ==="
ls -lh claude-rc-*.tgz
