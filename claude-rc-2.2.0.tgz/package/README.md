# claude-rc 使用手册

微信远程控制 Claude Code 的工具。在微信上发指令，Claude Code 在你的电脑上执行，结果发回微信。

## 工作原理

```
微信发消息 → iLink Bot API → MCP Server → Claude Code 执行 → 结果发回微信
                                              ↕
                                        PTY 监控终端输出
                                        检测交互提示 → 转发微信
                                        微信回复 → 注入回终端
```

claude-rc 用 PTY（伪终端）启动 Claude Code，同时：
- MCP Server 负责微信消息收发和任务调度
- PTY Runner 负责检测 Claude Code 的交互提示（权限确认等），转发到微信让你远程选择

---

## 前置条件

- macOS（Linux 未测试）
- Node.js >= 22
- Claude Code CLI 已安装（`claude --version` 能执行）
- iOS 微信 8.0.70+，「设置 → 插件」中 ClawBot 可用

---

## 安装

```bash
git clone git@github.com:tomszhou/claude-rc.git
cd claude-rc
npm install
npm run build
npm link          # 注册全局命令 claude-rc
```

验证安装：
```bash
claude-rc
# 应输出：请先登录: claude-rc login
```

---

## 第一步：扫码登录

```bash
claude-rc login
```

终端会输出一个二维码链接，用浏览器打开后微信扫码，手机上点确认。

登录成功后 token 自动保存到 `~/.weixin-mcp.json`（权限 600，仅自己可读）。

---

## 第二步：启动

```bash
claude-rc start
```

启动后会：
1. 用 PTY 启动 Claude Code（`--permission-mode auto`）
2. 自动注入系统 prompt（`weixin-system-prompt.md`）
3. 自动发送初始指令让 Claude 进入微信监听循环
4. 启动 IPC 通道连接 MCP Server
5. 启动看门狗监控

看到 Claude Code 的界面出现后，就可以在微信上发消息了。

---

## 日常使用

### 发送任务

微信直接发文字消息，Claude Code 会收到并执行。例如：

```
查看 toms-pay 项目的 git log 最近 5 条
```

```
把 src/utils.ts 里的 formatDate 函数改成用 dayjs
```

```
运行一下测试
```

### 交互提示

当 Claude Code 遇到需要你确认的操作（权限询问、工具授权等），会自动转发到微信：

```
🔔 Claude Code 需要你的输入:

Bash command
  rm /Users/xxx/test.md
  Delete test.md file

Do you want to proceed?
) 1. Yes
  2. Yes, and always allow access
  3. No

请直接回复选项编号或内容。
```

**直接回复数字**即可，如回复 `1` 表示选择 Yes。

当 Claude Code 弹出多选项提问（AskUserQuestion）时，会结构化提取选项列表：

```
🔔 [1/2] 金额单位
Claude Code 向你提问：

关于数据库设计中发现的金额单位不一致问题...

📋 选项：
1. 保留现有不动（推荐）
2. 全面迁移到分
3. 先看完整文档再决定

回复 /s1~/s3 选择，或直接输入文字。
```

### 控制命令

在微信中发送以下命令可以精确控制 Claude Code 的终端交互：

| 命令 | 说明 |
|------|------|
| `/s1` ~ `/s20` 或 `/select N` | 选择第 N 个选项（箭头键 + Enter） |
| `/submit` 或 `/enter` | 按 Enter 确认当前选项 |
| `/tab` 或 `/tab 金额单位` | 按 Tab 切换到下一个标签页 |
| `/esc` 或 `/escape` | 按 Esc 取消当前操作 |
| `/redo` 或 `/resend` | 重新发送上次的选项提示到微信 |
| `/restart` 或 `/reboot` | 完整重启 Claude Code（kill → respawn） |
| `/s` 或 `/status` | 查看当前状态 + 终端画面截屏 |
| `/model sonnet` | 切换模型并重启（支持 sonnet/opus/haiku） |
| `/model` | 使用默认模型重启 |

**多标签页自动引导**：当 Claude Code 弹出多标签选择界面（如"金额单位"、"默认Key"逐题选择）时，选完当前题后系统自动按 Tab 切换到下一题并推送新选项。最后一题选完后自动 Submit 提交。

### 高危操作

MCP Server 会自动检测高危操作（`rm -rf`、`git push --force`、`DROP TABLE` 等），发送确认请求：

```
⚠️ 需要你确认

操作：删除 dist 目录
风险：不可逆删除

请回复【确认】或【取消】
（2 分钟内无回复自动取消）
```

回复「确认」或「取消」。

### 进度通知

耗时任务会收到进度更新：
```
正在运行测试，共 156 个用例...
测试完成：152 通过，4 失败
已修复所有测试，全部 156 个用例通过
```

### 看门狗

如果 Claude Code 静默超过 5 分钟，会收到微信提醒：
```
⚠️ Claude Code 已静默 5 分钟，可能卡住了。
```

### Claude Code 退出

如果 Claude Code 进程退出，微信会收到通知：
```
⚠️ Claude Code 已退出 (code=0)
```

---

## 停止

在终端按 `Ctrl+C` 即可停止。会自动清理临时文件和 socket。

---

## Token 过期

微信 iLink Bot 的 token 会定期过期。过期后会收到微信通知：
```
⚠️ 微信登录已过期，请重新扫码：claude-rc login
```

重新执行：
```bash
claude-rc login
claude-rc start
```

---

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `CLAUDE_PERMISSION_MODE` | Claude Code 权限模式 | `auto` |
| `CLAUDE_PATH` | Claude CLI 路径 | 自动检测 |
| `CLAUDE_EXTRA_ARGS` | 额外 Claude CLI 参数（空格分隔） | 无 |
| `BOT_LANG` | 语言 `zh` / `en` | `zh` |
| `WEIXIN_USER_ID` | 覆盖微信用户 ID | 从登录文件读取 |
| `WEIXIN_BOT_TOKEN` | 覆盖 token | 从登录文件读取 |
| `CONFIRM_TIMEOUT_MS` | 确认超时（毫秒） | `120000` |

### 权限模式说明

| 模式 | 说明 |
|------|------|
| `auto` | **默认。** 大部分操作自动通过，少数需确认的通过 PTY 转发微信 |
| `default` | 所有工具调用都需确认，全部通过微信选择。最安全但交互频繁 |
| `bypassPermissions` | 跳过所有权限检查。**有安全风险，不建议使用** |

示例：
```bash
# 所有操作都要微信确认（最安全）
CLAUDE_PERMISSION_MODE=default claude-rc start

# 跳过权限（仅在完全信任的环境下使用）
CLAUDE_PERMISSION_MODE=bypassPermissions claude-rc start
```

---

## 自定义系统 Prompt

`weixin-system-prompt.md` 文件定义了 Claude Code 在微信远控模式下的行为规则，启动时自动注入。

可以编辑此文件来调整：
- 工作循环行为
- 进度通知规则
- 高危操作判定
- 回复格式风格
- 边界情况处理

修改后重启 `claude-rc start` 生效。

---

## 工作目录

`claude-rc start` 会在**当前目录**启动 Claude Code。要控制哪个项目，先 `cd` 到项目目录再启动：

```bash
cd ~/projects/my-app
claude-rc start
```

---

## 文件结构

```
claude-rc/
├── index.ts                  # MCP Server（被 Claude Code 自动加载）
├── src/
│   ├── cli.ts                # 主入口 — claude-rc start / login
│   ├── pty-runner.ts         # PTY 启动 + 交互提示检测
│   ├── prompt-detector.ts    # ANSI 清洗 + 关键字匹配
│   ├── ipc.ts                # Unix socket IPC 协议
│   ├── weixin-api.ts         # 微信 iLink Bot API
│   └── watchdog.ts           # 静默看门狗
├── weixin-system-prompt.md   # Claude Code 行为规则
├── docs/
│   ├── pty-lessons-learned.md  # PTY 开发经验
│   └── code-review.md         # 代码审查报告
├── package.json
└── tsconfig.json
```

---

## 故障排查

### claude-rc: command not found

```bash
cd claude-rc
npm link
```

### posix_spawnp failed

node-pty 与 Node.js 版本不兼容。确保使用 `node-pty@1.2.0-beta.12+`：
```bash
npm install node-pty@1.2.0-beta.12
npm run build
```

### IPC 连接不上

MCP Server 由 Claude Code 延迟启动（首次调用 MCP 工具时才 spawn）。PTY Runner 会自动重试连接，通常 5-10 秒内建立。

如果持续失败，检查 `~/.claude.json` 中是否有冲突的全局 `weixin` MCP 配置：
```bash
grep -A5 '"weixin"' ~/.claude.json
```
如果有，删掉它（claude-rc 通过 `--mcp-config` 自动注入）。

### 微信收不到消息

1. 确认 token 没过期：`claude-rc login` 重新扫码
2. 确认 `~/.weixin-mcp.json` 存在且有 token
3. 确认微信 ClawBot 插件已启用

### 交互提示没转发到微信

Claude Code 使用 Ink 全屏 TUI 渲染，提示检测依赖关键字匹配。如果某种新格式的提示没被检测到，可在 `src/prompt-detector.ts` 的 `PROMPT_KEYWORDS` 数组中添加关键字。

### 微信回复数字后没反应

Claude Code 的选择菜单使用方向键+回车，不是数字输入。推荐使用 `/s1`、`/s2` 等前缀命令（v2.2.0+），比直接发数字更可靠。如果卡住了，可以：
- 发送 `/redo` 重新获取选项列表
- 发送 `/esc` 取消当前操作
- 发送 `/restart` 重启 Claude Code

---

## 安全注意事项

- **不要在不信任的网络环境下使用 `bypassPermissions` 模式**
- Token 保存在 `~/.weixin-mcp.json`，权限 600（仅自己可读）
- 临时 MCP 配置文件使用 `mkdtemp` 创建私有目录
- 任何能给你微信发消息的人都可以向 Claude Code 发指令——确保你的微信聊天环境安全
- 高危操作（`rm -rf`、`git push --force` 等）会被自动拦截并请求确认

---

## 已知限制

- 仅支持一对一私聊，不支持群聊
- 仅支持文字消息，不支持图片/语音/文件
- 同一时间只能处理一个任务，新消息会在前一个任务完成后处理
- Token 会过期，需要定期重新扫码
- node-pty 目前使用 beta 版本（Node.js 25 兼容性要求）
